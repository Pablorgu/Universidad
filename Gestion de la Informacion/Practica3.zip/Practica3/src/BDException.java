
public class BDException extends RuntimeException  
{

	public BDException() 
	{
		super();
	}

	public BDException(String arg0) 
	{
		super(arg0);
	}
}
