package es.taw.junio2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Junio2023ApplicationTests {

    @Test
    void contextLoads() {
    }

}
