package es.taw.junio2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Junio2023Application {

    public static void main(String[] args) {
        SpringApplication.run(Junio2023Application.class, args);
    }

}
