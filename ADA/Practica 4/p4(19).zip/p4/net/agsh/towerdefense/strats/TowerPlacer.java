/*
Sustituir este comentario por una explicación de la formula o procedimiento empleado para determinar el valor de una
celda (MapNode).
*/

package net.agsh.towerdefense.strats;

import net.agsh.towerdefense.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class TowerPlacer {

    public static float getNodeValue(MapNode node, Map map) {
        float maxRange = Game.getInstance().getParam(Config.Parameter.TOWER_RANGE_MAX);
        int inRangeNodesCount = 0;

        for (MapNode n : Game.getInstance().getMap().getWalkableNodes()) {
            if (node.getPosition().distance(n.getPosition()) < maxRange) {
                inRangeNodesCount++;
            }
        }

        return (float) inRangeNodesCount;
    }

    public static boolean collide(Point2D entity1Position, float entity1Radius,
                                  Point2D entity2Position, float entity2Radius) {
        float distance = entity1Position.distance(entity2Position);
        float combinedRadius = entity1Radius + entity2Radius;

        return distance < combinedRadius;
    }

    public static ArrayList<Tower> placeTowers(ArrayList<Tower> towers, Map map) {
//        // This is just a (bad) example to show you how to use the entities in the game.
//        // Replace ALL of this with your own code.
//
//        // Get map size.
//        float mapWidth = map.getSize().x;
//        float mapHeight = map.getSize().y;
//
//        // Get parameters from the game.
//        float maxEnemyRadius = Game.getInstance().getParam(Config.Parameter.ENEMY_RADIUS_MAX);
//        float maxRange = Game.getInstance().getParam(Config.Parameter.TOWER_RANGE_MAX);
//
//        // Get nodes the enemies can walk on.
//        ArrayList<MapNode> walkableNodes = map.getWalkableNodes();
//
//        // Get obstacles.
//        ArrayList<Obstacle> obstacles = map.getObstacles();
//
//        // Get the grid of map nodes.
//        MapNode[][] grid = map.getNodes();
//
//        // Get the distance between two nodes.
//        MapNode n1 = grid[0][0];
//        MapNode n2 = grid[0][1];
//        float distance = n1.getPosition().distance(n2.getPosition());
//
//        // Each node has up to Config.Parameter.MAP_NODE_VALUES values. Default is 5.
//        // You can *optionally* use these values to store information about the nodes.
//        // Set the second value of node n1.
//        n1.setValue(2, getNodeValue(n1, map));
//
//        // Get the second value of node n1.
//        float value = n1.getValue(2);
//
//        Random random = new Random();
//        // Loop through the towers.
//        ArrayList<Tower> placedTowers = new ArrayList<>();
//        for (Tower tower : towers) {
//            // Place the tower on a random node.
//            MapNode node = grid[random.nextInt(grid.length)][random.nextInt(grid[0].length)];
//            tower.setPosition(node.getPosition());
//            placedTowers.add(tower);
//        }
        ArrayList<Tower> placedTowers = new ArrayList<>();
        ArrayList<MapNode> nodes = map.getNodesList();

        // Ordenar los nodos caminables según su valor (puedes ajustar el criterio según tus necesidades).
        setNodeValues(map.getNodesList(), map);
        Collections.sort(nodes, (node1, node2) -> Float.compare(node2.getValue(2), node1.getValue(2)));

        for (Tower tower : towers) {
            // Encuentra la mejor posición disponible para la torreta.
            MapNode bestNode = findBestNode(nodes, placedTowers, tower, map);

            if (bestNode != null) {
                // Coloca la torreta en la mejor posición y agrégala a la lista de torretas colocadas.
                tower.setPosition(bestNode.getPosition());
                placedTowers.add(tower);
            }
        }
        return placedTowers;
    }

    protected static boolean NoOutofBounds(Point2D position, float radius, Point2D mapSize) {
        return !(position.x > mapSize.x - radius) && !(position.y > mapSize.y - radius) && !(position.x < radius) &&  !(position.y < radius);
    }

    private static MapNode findBestNode(ArrayList<MapNode> nodes, ArrayList<Tower> placedTowers, Tower tower, Map map) {
        for (MapNode node : nodes) {
            Point2D nodePosition = node.getPosition();
            // Verifica si la posición está dentro de los límites y no colisiona con torres u obstáculos.
            if (NoOutofBounds(nodePosition, tower.getRadius(), map.getSize()) &&
                    !collidesWithTowers(nodePosition, tower.getRadius(), placedTowers) &&
                    !collidesWithObstacles(nodePosition, tower.getRadius(), map.getObstacles(),map.getWalkableNodes())) {
                return node; // Devuelve el primer nodo que cumple con las condiciones.
            }
        }
        return null; // No se encontró ningún nodo adecuado.
    }

    protected static boolean collidesWithTowers(Point2D position, float radius, ArrayList<Tower> towers) {
        for (Tower tower : towers) {
            if (collide(position, radius, tower.getPosition(), tower.getRadius())) {
                return true; // Hay una colisión con al menos una torreta existente.
            }
        }
        return false; // No hay colisión con ninguna torreta existente.
    }

    protected static boolean collidesWithObstacles(Point2D position, float radius, ArrayList<Obstacle> obstacles, ArrayList<MapNode> walkablenodes) {
        Game game = Game.getInstance();
        for (Obstacle obstacle : obstacles) {
            if (collide(position, radius, obstacle.getPosition(), obstacle.getRadius())) {
                return true; // Hay una colisión con al menos un obstáculo existente.
            }
        }
        for(MapNode celda : walkablenodes){
            if(collide(position,radius, celda.getPosition(),game.getParam(Config.Parameter.ENEMY_RADIUS_MAX))) {
                return true;
            }
        }
            return false; // No hay colisión con ningún obstáculo existente.
    }

    public static void setNodeValues(ArrayList<MapNode> nodes, Map map) {
        for (MapNode currentNode : nodes) {
            float nodeValue = getNodeValue(currentNode, map);
            currentNode.setValue(2, nodeValue);
        }
    }
}