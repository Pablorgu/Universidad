package analyzer;

import java.util.HashMap;
import java.util.Map;

public class Analyzer implements Runnable {
    Algorithm algorithm;
    long maxExecutionTime;
    static String complexity = null;
    static int nvueltas = 3;
    public Analyzer(Algorithm algorithm, long maxExecutionTime) {
        this.algorithm = algorithm;
        this.maxExecutionTime = maxExecutionTime;
    }

    public String getComplexity() {
        return complexity;
    }

    @Override
    public void run() {
        complexity = findComplexityOf(algorithm, maxExecutionTime);
    }

    static String findComplexityOf(Algorithm algorithm, long maxExecutionTime) {
        // Modify the content of this method in order to find the complexity of the given algorithm.
        // You can delete any of the following instructions if you don't need them. You can also
        // add new instructions or new methods, but you cannot modify the signature of this method
        // nor the existing methods.
        String[] complejidades = {"1", "log(n)", "n", "n*log(n)", "n^2", "n^3", "2^n"};
        int[] vals = {1000, 2000, 4000};

        long[] media = mediaEjecuciones(algorithm, vals);
        //Primero observo si es constante
        long[] medialgoritm= mediaEjecucionesalgo(algorithm, vals, 1);
        Double limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[0];
        }
        //Observo si es logaritmica
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 2);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[1];
        }
        //Observo si es lineal
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 3);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[2];
        }
        //Observo si es NlogN
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 4);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[3];
        }

        //adaptacion de variables
        vals = new int[]{100, 200, 400};
        media = mediaEjecuciones(algorithm, vals);
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 1);


        //Observo si es 2^N
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 5);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[6];
        }
        //Observo si es N^2
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 6);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[4];
        }
        //Observo si es N^3
        medialgoritm= mediaEjecucionesalgo(algorithm, vals, 7);
        limite=0.0;
        for(int i = 0; i < vals.length; i++) {
            limite += ((double) media[i] /medialgoritm[i]);
        }
        limite = limite/vals.length;
        if(limite < 1.5 && limite > 0.5) {
            complexity = complejidades[5];
        }

        return complexity;
    }

    private static void complejidadN3(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            for(int j = 0; j < numAEjecutar; j++) {
                for(int k = 0; k < numAEjecutar; k++) {
                    sum++;
                }
            }
        }
    }
    private static void complejidadN2(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            for(int j = 0; j < numAEjecutar; j++) {
                sum++;
            }
        }
    }
    private static void complejidadN(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            sum++;
        }
    }
    private static void complejidad2N (long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            sum++;
        }
        for(int j = 0; j < numAEjecutar; j++) {
            sum++;
        }
    }
    private static void complejidadNlogN(long numAEjecutar) {
        int sum = 0;
        for(int i = 1; i <= numAEjecutar; i=i*2) {
            for(int k = 0; k < numAEjecutar; k++) {
                sum++;
            }
        }
    }
    private static void complejidadlogN(long numAEjecutar) {
        int sum = 0;
        for(int i = 1; i <= numAEjecutar; i=i*2) {
            sum++;
        }
    }
    private static void complejidad1() {
        int sum = 0;
        sum++;
    }

    public static void init(long[] a){
        for(int i = 0; i < a.length; i++){
            a[i] = Long.MAX_VALUE;
        }
    }

    private static long[] mediaEjecuciones(Algorithm a, int[] vals){
        double media = 0;
        Chronometer chrono = new Chronometer();
        long[] tiempos = new long[vals.length];
        for(int i = 0; i<vals.length; i++) {
            for(int j = 0; j < nvueltas; j++) {
                a.init(vals[i]);
                chrono.start();
                a.run();
                chrono.stop();
                tiempos[i] += chrono.getElapsedTime();
            }
            tiempos[i] = tiempos[i]/nvueltas;
        }
        return tiempos;
    }

    private static long[] mediaEjecucionesalgo(Algorithm a, int[] vals, int opcion){
        double media = 0;
        Chronometer chrono = new Chronometer();
        long[] tiempos = new long[vals.length];
        for(int i = 0; i<vals.length; i++) {
            for(int j = 0; j < nvueltas; j++) {
                chrono.start();
                switch (opcion) {
                    case 1:
                        complejidad1();
                        break;
                    case 2:
                        complejidadlogN(vals[i]);
                        break;
                    case 3:
                        complejidadN(vals[i]);
                        break;
                    case 4:
                        complejidadNlogN(vals[i]);
                        break;
                    case 5:
                        complejidad2N(vals[i]);
                        break;
                    case 6:
                        complejidadN2(vals[i]);
                        break;
                    case 7:
                        complejidadN3(vals[i]);
                        break;
                    default:
                        System.out.println("Opción no válida");
                        break;
                }
                chrono.stop();
                tiempos[i] += chrono.getElapsedTime();
            }
            tiempos[i] = tiempos[i]/nvueltas;
        }
        return tiempos;
    }
}