package analyzer;

import java.util.HashMap;
import java.util.Map;

public class Analyzer implements Runnable {
    Algorithm algorithm;
    long maxExecutionTime;
    String complexity = null;
    public Analyzer(Algorithm algorithm, long maxExecutionTime) {
        this.algorithm = algorithm;
        this.maxExecutionTime = maxExecutionTime;
    }

    public String getComplexity() {
        return complexity;
    }

    @Override
    public void run() {
        complexity = findComplexityOf(algorithm, maxExecutionTime);
    }

    static String findComplexityOf(Algorithm algorithm, long maxExecutionTime) {
        // Modify the content of this method in order to find the complexity of the given algorithm.
        // You can delete any of the following instructions if you don't need them. You can also
        // add new instructions or new methods, but you cannot modify the signature of this method
        // nor the existing methods.
        String[] complejidades2 = {"1", "logN", "NlogN","2^N", "N", "N^2", "N^3"};
        int[] valsMin = {10, 100, 400, 800, 1000, 1500};
        int[] valsMax = {20, 200, 800, 1600, 2000, 3000};

        System.out.println("Complejidad de cada algoritmo: ");
        double media = mediaEjecuciones(algorithm, valsMin, valsMax);


        return complexity;
    }

    private static Map<String, Double> complejidades(int[] valsMin, int[] valsMax) {
        Map<String, Double> complejidadesYRatios= new HashMap<>();
        double media = 0;
        Chronometer chrono = new Chronometer();
        long[] tiemposMin= new long[valsMin.length];
        long[] tiemposMax= new long[valsMax.length];
        init(tiemposMin);
        init(tiemposMax);
        chrono.pause();
        for(int i = 0; i < valsMin.length; i++){
            chrono.start();
            complejidad1(valsMin[i]);
            chrono.stop();
            tiemposMin[i] = chrono.getElapsedTime();

            chrono.start();
            complejidad1(valsMax[i]);
            chrono.stop();
            tiemposMax[i] = chrono.getElapsedTime();
        }

        return complejidadesYRatios;
    }
    private static void complejidadN3(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            for(int j = 0; j < numAEjecutar; j++) {
                for(int k = 0; k < numAEjecutar; k++) {
                    sum++;
                }
            }
        }
    }
    private static void complejidadN2(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            for(int j = 0; j < numAEjecutar; j++) {
                sum++;
            }
        }
    }
    private static void complejidadN(long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            sum++;
        }
    }
    private static void complejidad2N (long numAEjecutar) {
        int sum = 0;
        for(int i = 0; i < numAEjecutar; i++) {
            sum++;
        }
        for(int j = 0; j < numAEjecutar; j++) {
            sum++;
        }
    }
    private static void complejidadNlogN(long numAEjecutar) {
        int sum = 0;
        for(int i = 1; i <= numAEjecutar; i=i*2) {
            for(int k = 0; k < numAEjecutar; k++) {
                sum++;
            }
        }
    }
    private static void complejidadlogN(long numAEjecutar) {
        int sum = 0;
        for(int i = 1; i <= numAEjecutar; i=i*2) {
            sum++;
        }
    }
    private static void complejidad1() {
        int sum = 0;
        sum++;
    }

    public static void init(long[] a){
        for(int i = 0; i < a.length; i++){
            a[i] = Long.MAX_VALUE;
        }
    }

    private static double mediaEjecuciones(Algorithm a, int[] valsMin, int[] valsMax){
        double media = 0;
        Chronometer chrono = new Chronometer();
        long[] tiemposMin= new long[valsMin.length];
        long[] tiemposMax= new long[valsMax.length];
        init(tiemposMin);
        init(tiemposMax);
        chrono.pause();
        for(int i = 0; i < valsMin.length; i++){
            a.init(valsMin[i]);
            chrono.start();
            a.run();
            chrono.stop();
            tiemposMin[i] = chrono.getElapsedTime();

            a.init(valsMax[i]);
            chrono.start();
            a.run();
            chrono.stop();
            tiemposMax[i] = chrono.getElapsedTime();
        }
        for(int i = 0; i < tiemposMin.length; i++){
            tiemposMin[i] = tiemposMin[i] / tiemposMax[i];
        }
        System.out.println("Tiempos Min: {");
        for(long tiemposMin1 : tiemposMin){
            System.out.println(tiemposMin1 + ", ");
        }
        System.out.println("}");
        for(long tiemposMin1 : tiemposMin){
            media += tiemposMin1;
        }
        return media;
    }
}
