java -cp ".:towerdefense.jar" Main GUI=1
